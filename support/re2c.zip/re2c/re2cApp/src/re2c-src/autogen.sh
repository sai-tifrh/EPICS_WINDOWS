#!/bin/sh

git clean -fXd
autoreconf -i -W all
