re2c: error: line 3, column 10: conditions are only allowed when using -c switch
