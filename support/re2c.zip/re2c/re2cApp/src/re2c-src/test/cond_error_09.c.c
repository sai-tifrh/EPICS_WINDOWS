re2c: error: line 6, column 6: code to setup rule 'a' is already defined
