re2c: error: line 3, column 4: unnamed condition not supported
