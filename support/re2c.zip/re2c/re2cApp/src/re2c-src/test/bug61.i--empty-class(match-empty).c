re2c: warning: line 2: empty character class [-Wempty-character-class]
re2c: warning: line 2: rule matches empty string [-Wmatch-empty-string]
re2c: warning: line 6: empty character class [-Wempty-character-class]
re2c: warning: line 6: rule matches empty string [-Wmatch-empty-string]
re2c: warning: line 10: empty character class [-Wempty-character-class]
re2c: warning: line 10: rule matches empty string [-Wmatch-empty-string]
re2c: warning: line 14: empty character class [-Wempty-character-class]
re2c: warning: line 14: empty character class [-Wempty-character-class]
re2c: error: line 14, column 11: can only difference char sets
