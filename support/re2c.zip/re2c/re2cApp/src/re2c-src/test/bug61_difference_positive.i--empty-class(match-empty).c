re2c: warning: line 2: empty character class [-Wempty-character-class]
re2c: warning: line 2: empty character class [-Wempty-character-class]
re2c: error: line 2, column 11: can only difference char sets
