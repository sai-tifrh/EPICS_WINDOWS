re2c: error: line 4, column 4: code to handle illegal condition already defined
