re2c: error: line 3, column 4: syntax error
