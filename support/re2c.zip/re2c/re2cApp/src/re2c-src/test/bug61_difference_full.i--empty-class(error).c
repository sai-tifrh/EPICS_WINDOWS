re2c: error: line 2, column 29: empty character class
