re2c: error: line 3, column 2: unnamed condition not supported
