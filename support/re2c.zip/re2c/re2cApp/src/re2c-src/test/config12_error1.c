re2c: error: line 3, column 7: unrecognized configuration
