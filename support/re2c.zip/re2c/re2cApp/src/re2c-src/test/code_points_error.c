re2c: error: line 2, column 1: Bad code point: '0xFFFF'
