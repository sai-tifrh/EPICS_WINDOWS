int fGetDateStr( char datetime[]);
 
