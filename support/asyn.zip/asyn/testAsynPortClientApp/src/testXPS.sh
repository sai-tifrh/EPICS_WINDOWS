../../bin/linux-x86_64/testAsynIPPortClient newport-xps1:5001 "FirmwareVersionGet(char *)"
