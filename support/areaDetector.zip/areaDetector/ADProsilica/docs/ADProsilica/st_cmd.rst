.. _ADProsilica_st_cmd_example:

Example st.cmd Startup File
===========================

.. literalinclude:: ../../../ADProsilica/iocs/prosilicaIOC/iocBoot/iocProsilica/st.cmd
