Example st.cmd Startup File
===========================

.. literalinclude:: ../../../ADSimDetector/iocs/simDetectorIOC/iocBoot/iocSimDetector/st.cmd

with st_base.cmd

.. literalinclude:: ../../../ADSimDetector/iocs/simDetectorIOC/iocBoot/iocSimDetector/st_base.cmd
