ADAndor
=======
An 
[EPICS](http://www.aps.anl.gov/epics)
[areaDetector](https://areadetector.github.io)
driver for CCD detectors from 
[Andor Technology]("http://www.andor.com) 
using Version 2 of the Andor Software Development Kit (SDK).


Additional information:
* [Documentation](https://areadetector.github.io/master/ADAndor/andorDoc.html)
* [Release notes](RELEASE.md)
