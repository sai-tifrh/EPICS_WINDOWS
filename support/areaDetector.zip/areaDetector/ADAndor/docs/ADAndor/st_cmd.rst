.. _ADAndor_st_cmd_example:

Example st.cmd Startup File
===========================

.. literalinclude:: ../../../ADAndor/iocs/andorIOC/iocBoot/iocAndor/st.cmd
