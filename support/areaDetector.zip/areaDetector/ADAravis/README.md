ADAravis
===========
An 
[EPICS](http://www.aps.anl.gov/epics)
[areaDetector](https://github.com/areaDetector/areaDetector/blob/master/README.md)
driver for
[GenICam](https://www.emva.org/standards-technology/genicam/) cameras using the
[Aravis](https://github.com/AravisProject/aravis) library.

Additional information:
* [Documentation](https://areadetector.github.io/master/ADAravis/ADAravis.html)
* [Release notes](RELEASE.md)
