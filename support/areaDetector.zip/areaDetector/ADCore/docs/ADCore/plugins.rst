areaDetector Plugins
=====================

.. toctree:: 
    :maxdepth: 2
    :caption: Table of Contents

    plugin_overview
    NDPluginDriver
    plugin_guidelines
    plugin_medm
    common_plugins
    plugin_performance
    NDPluginAttrPlot
    NDPluginAttribute
    NDPluginBadPixel
    NDPluginCircularBuff
    NDPluginCodec
    NDPluginColorConvert
    NDPluginFFT
    NDPluginFile
    NDPluginGather
    NDPluginOverlay
    NDPluginProcess
    NDPluginPva
    NDPluginROI
    NDPluginROIStat
    NDPluginScatter
    NDPluginStats
    NDPluginStdArrays
    NDPluginTimeSeries
    NDPluginTransform
    NDPluginPos
    ffmpegServer <ffmpegServer>
