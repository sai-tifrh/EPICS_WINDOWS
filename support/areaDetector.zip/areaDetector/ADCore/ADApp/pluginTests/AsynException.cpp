/*
 * AsynException.cpp
 *
 *  Created on: 24 Jun 2015
 *      Author: gnx91527
 */

#include "AsynException.h"

AsynException::AsynException()
{
}

AsynException::~AsynException() throw ()
{
}

