ADAndor3
========
An 
[EPICS](http://www.aps.anl.gov/epics/) 
[areaDetector](https://github.com/areaDetector/areaDetector/blob/master/README.md) 
driver for sCMOS detectors from 
[Andor Technology](http://www.andor.com)
using Version 3 of the Andor Software Development Kit (SDK).

Additional information:
* [Documentation](https://cars.uchicago.edu/software/epics/andor3Doc.html).
* [Release notes and links to source and binary releases](RELEASE.md).
