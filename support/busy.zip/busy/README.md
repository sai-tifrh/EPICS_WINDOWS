[![Build Status](https://travis-ci.org/epics-modules/busy.svg?branch=master)](https://travis-ci.org/epics-modules/busy)

# busy
APS BCDA synApps module: busy

* [**synApps/busy** home page](https://epics.anl.gov/bcda/synApps/busy/busy.html)
* [documentation](https://github.com/epics-modules/busy/blob/master/documentation/README.md)
* [Request a feature](https://github.com/epics-modules/busy/issues/new?title=%20FEATURE%20SHORT%20DESCRIPTION&body=**Feature%20Long%20Description**%0A%0A**Why%20should%20this%20be%20added?**%0A&labels=enhancement)
* [Report an issue with busy](https://github.com/epics-modules/busy/issues/new?title=%20ISSUE%20NAME%20HERE&body=**Describe%20the%20issue**%0A%0A**Steps%20to%20reproduce**%0A1.%20Step%20one%0A2.%20Step%20two%0A3.%20Step%20three%0A%0A**Expected%20behaivour**%0A%0A**Actual%20behaviour**%0A%0A**Build%20Environment**%0AArchitecture:%0AEpics%20Base%20Version:%0ADependent%20Module%20Versions:&labels=bug)
* [synApps home page](https://epics.anl.gov/bcda/synApps)

converted from APS SVN repository: Fri Oct 16 12:24:04 CDT 2015
